namespace DOTS.DOD.GRAPHICS.LESSON2
{
    public partial class GraphicsLesson2SystemGroup : SceneSystemGroup
    {
        protected override string SceneName => "WaveCubesWithColorChange";
    }
}

