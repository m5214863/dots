namespace DOTS.DOD.LESSON0
{
    public partial class CubeRotateSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "RotateCubeAuthoring";
    }
}
