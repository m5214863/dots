namespace DOTS.DOD.LESSON4
{
    public partial class WaveCubesWithDotsSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "WaveCubesWithDots";
    }
}