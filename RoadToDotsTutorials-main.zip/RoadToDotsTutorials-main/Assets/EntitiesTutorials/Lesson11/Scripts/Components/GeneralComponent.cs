using Unity.Entities;
using UnityEngine;

namespace DOTS.DOD.LESSON11
{
    struct GeneralComponent : IComponentData
    {
        public int num;
    }
}
