

using Unity.Entities;

namespace DOTS.DOD.LESSON11
{
    public partial class Lesson11SystemGroup : ComponentSystemGroup
    {
    }
}

