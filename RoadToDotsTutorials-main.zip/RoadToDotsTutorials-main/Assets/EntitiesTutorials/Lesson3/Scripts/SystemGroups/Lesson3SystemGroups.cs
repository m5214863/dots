namespace DOTS.DOD.LESSON3
{
    public partial class CreateEntitiesByPrefabSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "CreateEntitiesByPrefab";
    }
}