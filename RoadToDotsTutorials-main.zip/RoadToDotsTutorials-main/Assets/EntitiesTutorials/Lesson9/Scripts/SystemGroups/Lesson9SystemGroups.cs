using DOTS.DOD;

namespace DOTS.DOD.LESSON9
{
    public partial class SpawnerBlobSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "GenerateSpawnerByScript";
    }
}

