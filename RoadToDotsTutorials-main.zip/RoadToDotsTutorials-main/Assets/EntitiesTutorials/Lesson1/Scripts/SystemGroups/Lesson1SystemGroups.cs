namespace DOTS.DOD.LESSON1
{
    public partial class RotateCubesFilterSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "RotateCubesFilter";
    }
    
}